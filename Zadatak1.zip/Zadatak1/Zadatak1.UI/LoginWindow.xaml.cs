﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Zadatak1.Model;
using Zadatak1.ViewModel;

namespace Zadatak1.UI
{
    /// <summary>
    /// Interaction logic for LoginWindow.xaml
    /// </summary>
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();
        }

        private void ValidateLogin(string userName, string userPass)
        {
            if (userName == "" || userPass == "")
            {
                MessageBox.Show("Please insert your Username and Password!", "Message");
                return;
            }

            if (User.GetUserSearch(userName, userPass))
            {
                MainWindow main = new MainWindow();
                main.DataContext = new MainWindowViewModel(userName, userPass, Mediator.Instance);
                main.ShowDialog();
            }
            else
            {
                MessageBox.Show("Login failed. Please try again", "Message");
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            ValidateLogin(TextBoxUserName.Text, TextBoxPassword.Text);
        }
    }
}
