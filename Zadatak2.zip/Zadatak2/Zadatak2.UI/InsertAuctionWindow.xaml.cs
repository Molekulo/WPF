﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;
using Zadatak2.Model;
using Zadatak2.ViewModel;

namespace Zadatak2.UI
{
    /// <summary>
    /// Interaction logic for InsertAuctionWindow.xaml
    /// </summary>
    public partial class InsertAuctionWindow : Window
    {
        public InsertAuctionWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string stprice = Convert.ToString(TextBoxPrice.Text);
            bool checkTitle = Auction.GetTitleSearch(TextBoxTitle.Text);

            if (stprice == "" || TextBoxTitle.Text == "" || TextBoxInfo.Text == "")
            {
                MessageBox.Show("Unesite sve podatke!");
            }
            else if(checkTitle)
            {
                MessageBox.Show("Naziv aukcije vec postoji. Odaberite drugi naziv!");
                TextBoxTitle.Text = "";
            }
            else
            {            
                double price = double.Parse(TextBoxPrice.Text);
                string title = TextBoxTitle.Text;
                string info = TextBoxInfo.Text;

                Auction auction = new Auction();
                auction.InsertProduct(price, title, info);
                MessageBox.Show("Uspešno ste uneli podatke!");
                this.Hide();
                MainWindow main = new MainWindow();
                main.ShowDialog();
                this.Close();
            }  
        }
    }
}
