﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadatak2.Model
{
    public class User : INotifyPropertyChanged
    {
        private int id;
        private string userName;
        private string userPass;
        private int isAdmin;

        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged(PropertyChangedEventArgs e)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, e);
            }
        }

        public int Id
        {
            get { return id; }
            set
            {
                if (id == value) return;
                id = value;
                OnPropertyChanged(new PropertyChangedEventArgs("Id"));
            }
        }

        public string UserName
        {
            get { return userName; }
            set
            {
                if (userName == value) return;
                userName = value;
                OnPropertyChanged(new PropertyChangedEventArgs("UserName"));
            }
        }

        public string UserPass
        {
            get { return userPass; }
            set
            {
                if (userPass == value) return;
                userPass = value;
                OnPropertyChanged(new PropertyChangedEventArgs("UserPass"));
            }
        }

        public int IsAdmin
        {
            get { return isAdmin; }
            set
            {
                if (isAdmin == value) return;
                isAdmin = value;
                OnPropertyChanged(new PropertyChangedEventArgs("IsAdmin"));
            }
        }

        public User(string userName)
        {
            this.UserName = userName;
        }

        public User()
        {
            this.UserName = userName;
            this.Id = id;
        }

        public static bool GetUserSearch(string UserName, string UserPass)
        {
            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = ConfigurationManager.ConnectionStrings["ConnString1"].ToString();
                conn.Open();

                SqlCommand command = new SqlCommand("SELECT UserName, UserPass FROM Users WHERE UserName = '" + UserName + "' AND UserPass = '" + UserPass + "'", conn);

                using (SqlDataReader reader = command.ExecuteReader())
                {
                    return reader.HasRows ? true : false;
                }
            }
        }

        public static bool GetUserStatus(string UserName, string UserPass) //if true - admin, if false - regular user
        {
            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = ConfigurationManager.ConnectionStrings["ConnString1"].ToString();
                conn.Open();

                SqlCommand command = new SqlCommand("SELECT IsAdmin FROM Users WHERE UserName = '" + UserName + "' AND UserPass = '" + UserPass + "'", conn);

                var number = command.ExecuteScalar();

                if ((int)number == 1)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

    }
}
