﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Zadatak2.Model;

namespace Zadatak2.ViewModel
{
    public class MainWindowViewModel : INotifyPropertyChanged
    {
        private Auction currentAuction;
        private AuctionCollection auctionList;
        private User currentUser;
        //private IEnumerable<User> userLinqList;
        //private Mediator mediator;

        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChange(PropertyChangedEventArgs e)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, e);
            }
        }

        public Auction CurrentAuction
        {
            get { return currentAuction; }
            set
            {
                if (currentAuction == value) return;
                currentAuction = value;
                OnPropertyChange(new PropertyChangedEventArgs("CurrentAuction"));
            }
        }

        public AuctionCollection AuctionList
        {
            get { return auctionList; }
            set
            {
                if (auctionList == value) return;
                auctionList = value;
                OnPropertyChange(new PropertyChangedEventArgs("AuctionList"));
            }
        }

        public User CurrentUser
        {
            get { return currentUser; }
            set
            {
                if (currentUser == value) return;
                currentUser = value;
                OnPropertyChange(new PropertyChangedEventArgs("CurrentUser"));
            }
        }

        public MainWindowViewModel()
        {
            AuctionList = AuctionCollection.GetAllAuctions();
        }
    }
}
