﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadatak2.Model
{
    public class Auction : INotifyPropertyChanged
    {
        private int id;
        private string title;
        private double price;
        private string info;
        private int isActive;
        private double lastPrice;
        private string lastUser;
        private TimeSpan time;
        public bool ShowAuction;

        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged(PropertyChangedEventArgs e)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, e);
            }
        }

        public static TimeSpan GetTime(string title)
        {
            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = ConfigurationManager.ConnectionStrings["ConnString1"].ToString();
                conn.Open();

                SqlCommand command = new SqlCommand("SELECT Time FROM Products WHERE Title = @Title", conn);

                SqlParameter TitleParam = new SqlParameter("@Title", SqlDbType.VarChar, 50);
                TitleParam.Value = title;

                command.Parameters.Add(TitleParam);

                object time = (object)command.ExecuteScalar();
                return (TimeSpan)time;
            }
        }

        public static bool GetTitleSearch(string title)
        {
            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = ConfigurationManager.ConnectionStrings["ConnString1"].ToString();
                conn.Open();

                SqlCommand command = new SqlCommand("SELECT Title FROM Products WHERE Title = @Title", conn);

                SqlParameter TitleParam = new SqlParameter("@Title", SqlDbType.VarChar, 50);
                TitleParam.Value = title;

                command.Parameters.Add(TitleParam);

                using (SqlDataReader reader = command.ExecuteReader())
                {
                    return reader.HasRows ? true : false;
                }
            }
        }

        public static object GetLastPrice(string title)
        {
            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = ConfigurationManager.ConnectionStrings["ConnString1"].ToString();
                conn.Open();

                SqlCommand command = new SqlCommand("SELECT LastPrice FROM Products WHERE Title = @Title", conn);

                SqlParameter TitleParam = new SqlParameter("@Title", SqlDbType.VarChar, 50);
                TitleParam.Value = title;

                command.Parameters.Add(TitleParam);

                object lastPrice = command.ExecuteScalar();
                return lastPrice;
            }
        }

        public static object GetLastUser(string title)
        {
            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = ConfigurationManager.ConnectionStrings["ConnString1"].ToString();
                conn.Open();

                SqlCommand command = new SqlCommand("SELECT LastUser FROM Products WHERE Title = @Title", conn);

                SqlParameter TitleParam = new SqlParameter("@Title", SqlDbType.VarChar, 50);
                TitleParam.Value = title;

                command.Parameters.Add(TitleParam);

                object lastUser = command.ExecuteScalar();
                return lastUser;
            }
        }

        public static void MakeInactive(string title)
        {
            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = ConfigurationManager.ConnectionStrings["ConnString1"].ToString();
                conn.Open();

                SqlCommand command = new SqlCommand("UPDATE Products SET IsActive=0 WHERE Title = @Title", conn);

                SqlParameter TitleParam = new SqlParameter("@Title", SqlDbType.VarChar, 50);
                TitleParam.Value = title;

                command.Parameters.Add(TitleParam);

                int rows = command.ExecuteNonQuery();
            }
        }

        public void UpdateOffer(string UserName, double price, int Id)
        {
            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = ConfigurationManager.ConnectionStrings["ConnString1"].ToString();
                conn.Open();

                SqlCommand command = new SqlCommand("UPDATE Products SET LastPrice=@LastPrice, LastUser=@LastUser WHERE Id = @Id", conn);

                SqlParameter LastPriceParam = new SqlParameter("@LastPrice", SqlDbType.Float, 30);
                LastPriceParam.Value = price + 1;

                SqlParameter LastUserParam = new SqlParameter("@LastUser", SqlDbType.VarChar, 50);
                LastUserParam.Value = UserName;

                SqlParameter idParam = new SqlParameter("@Id", SqlDbType.Int);
                idParam.Value = Id;

                command.Parameters.Add(LastPriceParam);
                command.Parameters.Add(LastUserParam);
                command.Parameters.Add(idParam);
                command.ExecuteNonQuery();
            }
        }

        public void InsertProduct(double price, string title, string info)
        {
            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = ConfigurationManager.ConnectionStrings["ConnString1"].ToString();
                conn.Open();

                SqlCommand command = new SqlCommand("INSERT INTO Products(Price, Title, Information, IsActive, LastPrice, LastUser, Time) VALUES(@Price, @Title, @Information, 1, @Price, '', '00:02:00')", conn);

                SqlParameter PriceParam = new SqlParameter("@Price", SqlDbType.Float);
                PriceParam.Value = price;

                SqlParameter TitleParam = new SqlParameter("@Title", SqlDbType.NVarChar);
                TitleParam.Value = title;

                SqlParameter InfoParam = new SqlParameter("@Information", SqlDbType.NVarChar);
                InfoParam.Value = info;

                command.Parameters.Add(PriceParam);
                command.Parameters.Add(TitleParam);
                command.Parameters.Add(InfoParam);
                command.ExecuteNonQuery();
            }
        }

        public void DeleteProduct(string title)
        {
            using (SqlConnection conn = new SqlConnection())
            {

                conn.ConnectionString = ConfigurationManager.ConnectionStrings["ConnString1"].ToString();
                conn.Open();

                SqlCommand command = new SqlCommand("UPDATE Products SET IsActive = 0 WHERE Title=@Title", conn);

                SqlParameter TitleParam = new SqlParameter("@Title", SqlDbType.VarChar, 50);
                TitleParam.Value = title;

                command.Parameters.Add(TitleParam);

                int rows = command.ExecuteNonQuery();
            }
        }

        public void ResetTime(string title)
        {
            using (SqlConnection conn = new SqlConnection())
            {

                conn.ConnectionString = ConfigurationManager.ConnectionStrings["ConnString1"].ToString();
                conn.Open();

                SqlCommand command = new SqlCommand("UPDATE Products SET Time = '00:02:00' WHERE Title=@Title", conn);

                SqlParameter TimeParam = new SqlParameter("@TimeSpan", SqlDbType.Time, 7);
                TimeParam.Value = time;

                SqlParameter TitleParam = new SqlParameter("@Title", SqlDbType.VarChar, 50);
                TitleParam.Value = title;

                command.Parameters.Add(TimeParam);
                command.Parameters.Add(TitleParam);

                int rows = command.ExecuteNonQuery();
            }
        }

        public static void UpdateTime(TimeSpan time, string title)
        {
            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = ConfigurationManager.ConnectionStrings["ConnString1"].ToString();
                conn.Open();

                SqlCommand command = new SqlCommand("UPDATE Products SET Time = @Time WHERE Title=@Title", conn);

                SqlParameter TimeParam = new SqlParameter("@Time", SqlDbType.Time, 7);
                TimeParam.Value = time;

                SqlParameter TitleParam = new SqlParameter("@Title", SqlDbType.VarChar, 50);
                TitleParam.Value = title;

                command.Parameters.Add(TimeParam);
                command.Parameters.Add(TitleParam);
                command.ExecuteNonQuery();
            }

        }

        public int ID
        {
            get { return id; }
            set
            {
                if (id == value) return;
                id = value;
                OnPropertyChanged(new PropertyChangedEventArgs("ID"));
            }
        }

        public string Title
        {
            get { return title; }
            set
            {
                if (title == value) return;
                title = value;
                OnPropertyChanged(new PropertyChangedEventArgs("Title"));
            }
        }

        public double Price
        {
            get { return price; }
            set
            {
                if (price == value) return;
                price = value;
                OnPropertyChanged(new PropertyChangedEventArgs("Price"));
            }
        }

        public TimeSpan Time
        {
            get { return time; }
            set
            {
                if (time == value) return;
                time = value;
                OnPropertyChanged(new PropertyChangedEventArgs("Time"));
            }
        }

        public double LastPrice
        {
            get { return lastPrice; }
            set
            {
                if (lastPrice == value) return;
                lastPrice = value;
                OnPropertyChanged(new PropertyChangedEventArgs("LastPrice"));
            }
        }

        public string Info
        {
            get { return info; }
            set
            {
                if (info == value) return;
                info = value;
                OnPropertyChanged(new PropertyChangedEventArgs("Info"));
            }
        }

        public string LastUser
        {
            get { return lastUser; }
            set
            {
                if (lastUser == value) return;
                lastUser = value;
                OnPropertyChanged(new PropertyChangedEventArgs("LastUser"));
            }
        }

        public int IsActive
        {
            get { return isActive; }
            set
            {
                if (isActive == value) return;
                isActive = value;
                OnPropertyChanged(new PropertyChangedEventArgs("IsActive"));
            }
        }

        public Auction(int id, string title, double price, int isActive, double lastPrice, string lastUser, TimeSpan time)
        {
            this.ID = id;
            this.Title = title;
            this.IsActive = isActive;
            this.Price = price;
            this.LastPrice = lastPrice;
            this.LastUser = lastUser;
            this.Time = time;

            if (isActive == 1)
            {
                this.ShowAuction = true;
            }
            else
            {
                this.ShowAuction = false;
            }
        }

        public Auction()
        {
            this.ID = id;
            this.Title = title;
            this.IsActive = isActive;
            this.Price = price;

            if (isActive == 1)
            {
                this.ShowAuction = true;
            }
            else
            {
                this.ShowAuction = false;
            }
        }

        public static Auction GetAuctionFromProducts(SqlDataReader reader)
        {
            Auction auction = new Auction((int)reader["ID"],(string)reader["Title"], (double)reader["Price"], (int)reader["IsActive"], (double)reader["LastPrice"], (string)reader["LastUser"], (TimeSpan)reader["Time"]);
            return auction;
        }
    }
}
