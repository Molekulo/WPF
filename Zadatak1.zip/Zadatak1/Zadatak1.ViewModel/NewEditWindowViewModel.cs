﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using Zadatak1.Model;

namespace Zadatak1.ViewModel
{
    public class NewEditWindowViewModel : INotifyPropertyChanged
    {
        private User currentUser;
        private string windowTitle;
        private ICommand saveCommand;
        private Mediator mediator;

        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChange(PropertyChangedEventArgs e)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, e);
            }
        }

        public User CurrentUser
        {
            get { return currentUser; }
            set
            {
                if (currentUser == value) return;
                currentUser = value;
                OnPropertyChange(new PropertyChangedEventArgs("CurrentUser"));
            }
        }

        public string WindowTitle
        {
            get { return windowTitle; }
            set
            {
                if (windowTitle == value) return;
                windowTitle = value;
                OnPropertyChange(new PropertyChangedEventArgs("WindowTitle"));
            }
        }

        public ICommand SaveCommand
        {
            get { return saveCommand; }
            set
            {
                if (saveCommand == value) return;
                saveCommand = value;
                OnPropertyChange(new PropertyChangedEventArgs("SaveCommand"));
            }
        }

        void SaveExecute(object obj)
        {
            if (CurrentUser != null && !CurrentUser.HasErrors)
            {
                CurrentUser.Save();
                MessageBox.Show("User is saved!");
                mediator.Notify("UserChange", CurrentUser);
            }
            else
            {
                MessageBox.Show("User is not saved.Please check your fields!");
            }
        }

        bool CanSave(object obj)
        {
            return true;
        }

        public NewEditWindowViewModel(Mediator mediator)
        {
            this.mediator = mediator;
            CurrentUser = new User();
            SaveCommand = new RelayCommand(SaveExecute, CanSave);
            WindowTitle = "New User";
        }

        public NewEditWindowViewModel(User user, Mediator mediator)
        {
            this.mediator = mediator;
            SaveCommand = new RelayCommand(SaveExecute, CanSave);
            CurrentUser = user;
            WindowTitle = "Edit User";
        }
    }
}
