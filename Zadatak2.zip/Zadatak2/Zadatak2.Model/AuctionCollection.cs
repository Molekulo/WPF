﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadatak2.Model
{
    public class AuctionCollection : ObservableCollection<Auction>
    {
        public static AuctionCollection GetAllAuctions()
        {
            AuctionCollection auctions = new AuctionCollection();
            Auction auction = null;

            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = ConfigurationManager.ConnectionStrings["ConnString1"].ToString();
                conn.Open();

                SqlCommand command = new SqlCommand("SELECT Id, Title, Price, IsActive, LastPrice, LastUser, Time FROM Products", conn);

                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        auction = Auction.GetAuctionFromProducts(reader);
                        if (auction.ShowAuction)
                        {
                            auctions.Add(auction);
                        }   
                    }
                }
            }
            return auctions;
        }  
    }
}
