﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;
using Zadatak1.Model;

namespace Zadatak1.ViewModel
{
    public class MainWindowViewModel : INotifyPropertyChanged
    {
        private User currentUser;
        private UserCollection userList;
        private IEnumerable<User> userLinqList;
        private Mediator mediator;

        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChange(PropertyChangedEventArgs e)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, e);
            }
        }

        public User CurrentUser
        {
            get { return currentUser; }
            set
            {
                if (currentUser == value) return;
                currentUser = value;
                OnPropertyChange(new PropertyChangedEventArgs("CurrentUser"));
            }
        }

        public UserCollection UserList
        {
            get { return userList; }
            set
            {
                if (userList == value) return;
                userList = value;
                OnPropertyChange(new PropertyChangedEventArgs("UserList"));
            }
        }

        public IEnumerable<User> UserLinqList
        {
            get { return userLinqList; }
            set
            {
                if (userLinqList == value)
                {
                    return;
                }
                userLinqList = value;
                OnPropertyChange(new PropertyChangedEventArgs("UserLinqList"));
            }
        }

        public MainWindowViewModel(string currentUser, string currentPass, Mediator mediator)
        {
            this.mediator = mediator;
            CurrentUser = new User(currentUser, currentPass);
            UserList = UserCollection.GetAllUsers();
            mediator.Register("UserChange", UserChanged);
        }

        private void UserChanged(object obj)
        {
            User user = (User)obj;

            int index = UserList.IndexOf(user);

            if (index != -1)
            {
                UserList.RemoveAt(index);
                UserList.Insert(index, user);
            }
            else
            {
                UserList.Add(user);
            }
        }

        public MainWindowViewModel(Mediator mediator)
        {
            this.mediator = mediator;
            CurrentUser = new User();
            UserList = UserCollection.GetAllUsers();
            mediator.Register("UserChange", UserChanged);
        }
    }
}
