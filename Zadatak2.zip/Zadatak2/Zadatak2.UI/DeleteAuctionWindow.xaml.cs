﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Zadatak2.Model;
using Zadatak2.ViewModel;

namespace Zadatak2.UI
{
    /// <summary>
    /// Interaction logic for DeleteAuctionWindow.xaml
    /// </summary>
    public partial class DeleteAuctionWindow : Window
    {
        public DeleteAuctionWindow()
        {
            InitializeComponent();
            this.DataContext = new MainWindowViewModel();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //ovde ide brisanje aukcije
            string title = TextBlockTitle.Text;
            Auction auction = new Auction();
            auction.DeleteProduct(title);
            this.Hide();
            MainWindow main = new MainWindow();
            main.ShowDialog();
            this.Close();
        }
    }
}
