﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using Zadatak2.Model;
using Zadatak2.ViewModel;

namespace Zadatak2.UI
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public bool ValidUser;
        public string title;
        public static TimeSpan time;
        public TimeSpan pocetak;

        private void ListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            string title = TextBoxTitle.Text;
            time = Auction.GetTime(TextBoxTitle.Text);
            pocetak = time;
            TextBoxPonudjac.Text = Auction.GetLastUser(title).ToString();
            dispatcherTimer.Start();
        }

        public MainWindow()
        {
            InitializeComponent();
            this.DataContext = new MainWindowViewModel();
            
        }

        private DispatcherTimer dispatcherTimer = new DispatcherTimer();
        private TimeSpan kraj = new TimeSpan(0, 0, 0);

        private void dispatcherTimer_Tick(object sender, EventArgs e)
        {
            TextBoxTime.Text = pocetak.ToString();
            if (pocetak == kraj)
            {
                if(TextBoxPonudjac.Text == "")
                {
                    MessageBox.Show("Isteklo vreme. Nema pobednika!");
                }
                else
                {
                    MessageBox.Show("Isteklo vreme. Za aukciju " + TextBoxTitle.Text + " pobednik je " + TextBoxPonudjac.Text);
                }

                dispatcherTimer.Stop();
                TextBoxTime.Text = "Isteklo vreme";
                Auction.MakeInactive(TextBoxTitle.Text);
                return;
            }
            else
            {
                pocetak -= new TimeSpan(0, 0, 1);
                TextBoxTime.Text = pocetak.ToString();
                Auction.UpdateTime(pocetak, TextBoxTitle.Text);
            }
        }

        public static RoutedUICommand Offer = new RoutedUICommand("Offer", "Offer", typeof(MainWindow));

        private void Offer_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            Auction auction = new Auction();
            int id = int.Parse(TextBoxId.Text);
            string user = TextBlockStatus.Text;
            double price = double.Parse(TextBoxLast.Text);
            TextBoxPonudjac.Text = TextBlockStatus.Text;
            auction.UpdateOffer(TextBoxPonudjac.Text, price, id);
            MessageBox.Show("Ponudili ste 1€!");
            auction.ResetTime(TextBoxTitle.Text);
            time = Auction.GetTime(TextBoxTitle.Text);
            pocetak = time;
            TextBoxLast.Text = Auction.GetLastPrice(TextBoxTitle.Text).ToString();   
        }

        private void Offer_CanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            if (this.ValidUser && !(pocetak == kraj))
            {
                e.CanExecute = true;                    
            }
            else
            {
                e.CanExecute = false;
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            dispatcherTimer.Interval = new TimeSpan(0, 0, 1);
            dispatcherTimer.Tick += new EventHandler(dispatcherTimer_Tick);
        }
    }
}
