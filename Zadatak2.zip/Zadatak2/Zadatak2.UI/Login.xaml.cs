﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Zadatak2.Model;
using Zadatak2.ViewModel;

namespace Zadatak2.UI
{
    /// <summary>
    /// Interaction logic for Login.xaml
    /// </summary>
    public partial class Login : Window
    {
        public Login()
        {
            InitializeComponent();
        }

        public static RoutedUICommand Loging = new RoutedUICommand("Loging", "Loging", typeof(Login));
        public static RoutedUICommand NoLoging = new RoutedUICommand("NoLoging", "NoLoging", typeof(Login));

        private void Loging_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            //this is empty
            ValidateLogin(TextBoxUser.Text, TextBoxPass.Password);
        }

        private void Loging_CanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            if(TextBoxUser.Text == "" || TextBoxPass.Password == "")
            {
                e.CanExecute = false;
            }
            else
            {
                e.CanExecute = true;
            }
        }

        private void NoLoging_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            this.Hide();
            MainWindow main = new MainWindow();
            main.TextBlockStatus.Text = "Not Registered";
            //ovde ide data context iz viewmodel klase
            main.ShowDialog();
            this.Show();
        }

        private void NoLoging_CanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            if (TextBoxUser.Text=="" || TextBoxPass.Password == "")
            {
                e.CanExecute = true;
            }
            else
            {
                e.CanExecute = false;
            }
        }

        private void ValidateLogin(string userName, string userPass)
        {
            if (User.GetUserSearch(userName, userPass))
            {
                if(User.GetUserStatus(userName, userPass))
                {
                    this.Hide();
                    AdminWindow admin = new AdminWindow();
                    admin.ShowDialog();
                    this.Show();
                }
                else
                {
                    MainWindow main = new MainWindow();
                    main.ValidUser = true;
                    //main.DataContext = new MainWindowViewModel();
                    User user = new User(userName);
                    main.TextBlockStatus.Text = user.UserName;
                    main.ShowDialog();
                }
            }
            else
            {
                MessageBox.Show("Login failed. Please check your username and password!", "Message");
            }
        }
    }
}
