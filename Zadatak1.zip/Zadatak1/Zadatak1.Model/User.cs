﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadatak1.Model
{
    public class User : INotifyPropertyChanged, INotifyDataErrorInfo
    {
        private int id;
        private string userName;
        private string userPass;
        private int isAdmin;
        private bool showAdmin;
        private Dictionary<string, string> errors = new Dictionary<string, string>();

        public event PropertyChangedEventHandler PropertyChanged;
        public event EventHandler<DataErrorsChangedEventArgs> ErrorsChanged;

        public void OnPropertyChange(PropertyChangedEventArgs e)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, e);
            }
        }

        public int ID
        {
            get { return id; }
            set
            {
                if (id == value) return;
                id = value;
                OnPropertyChange(new PropertyChangedEventArgs("ID"));
            }
        }

        public string UserName
        {
            get { return userName; }
            set
            {
                if (userName == value) return;
                userName = value;

                bool valid = true;

                if (string.IsNullOrEmpty(value))
                {
                    SetErrors("Username", "Username can't be empty");
                    valid = false;
                }

                if (valid)
                {
                    ClearErrors("Username");
                }

                OnPropertyChange(new PropertyChangedEventArgs("UserName"));
            }
        }

        public string UserPass
        {
            get { return userPass; }
            set
            {
                if (userPass == value) return;
                userPass = value;

                bool valid = true;

                if(string.IsNullOrEmpty(value))
                {
                    SetErrors("Userpass", "Userspass can't be empty");
                    valid = false;
                }

                if (valid)
                {
                    ClearErrors("Userpass");
                }

                OnPropertyChange(new PropertyChangedEventArgs("UserPass"));
            }
        }

        public int IsAdmin
        {
            get { return isAdmin; }
            set
            {
                if (isAdmin == value) return;
                isAdmin = value;
                OnPropertyChange(new PropertyChangedEventArgs("IsAdmin"));
            }
        }

        public bool ShowAdmin
        {
            get { return showAdmin; }
            set
            {
                if (showAdmin == value) return;
                showAdmin = value;
                OnPropertyChange(new PropertyChangedEventArgs("ShowAdmin"));
            }
        }

        public bool HasErrors
        {
            get
            {
                return (errors.Count > 0);
            }
        }

        public User(int id, string userName, string userPass, int isAdmin)
        {
            this.ID = id;
            this.UserName = userName;
            this.UserPass = userPass;
            this.IsAdmin = isAdmin;

            if (isAdmin == 1)
            {
                this.ShowAdmin = true;
            }
            else
            {
                this.ShowAdmin = false;
            }
        }

        public User(string userName, string userPass)
        {
            this.UserName = userName;
            this.UserPass = userPass;
        }

        public User()
        {
            this.UserName = "";
            this.UserPass = "";
        }

        public static User GetUserFromResultSet(SqlDataReader reader)
        {
            User user = new User((int)reader["ID"], (string)reader["UserName"], (string)reader["UserPass"], (int)reader["IsAdmin"]);
            return user;
        }

        public static bool GetUserSearch(string UserName, string UserPass)
        {
            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = ConfigurationManager.ConnectionStrings["ConnString"].ToString();
                conn.Open();

                SqlCommand command = new SqlCommand("SELECT UserName, UserPass FROM Users WHERE UserName = '" + UserName + "' AND UserPass = '" + UserPass + "'", conn);

                using (SqlDataReader reader = command.ExecuteReader())
                {
                    return reader.HasRows ? true : false;
                }
            }
        }

        public void UpdateUser()
        {
            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = ConfigurationManager.ConnectionStrings["ConnString"].ToString();
                conn.Open();

                SqlCommand command = new SqlCommand("UPDATE Users SET UserName=@UserName, UserPass=@UserPass, IsAdmin=@IsAdmin WHERE id=@Id", conn);

                SqlParameter userNameParam = new SqlParameter("@UserName", SqlDbType.VarChar, 30);
                userNameParam.Value = this.UserName;

                SqlParameter userPassParam = new SqlParameter("@UserPass", SqlDbType.VarChar, 50);
                userPassParam.Value = this.UserPass;

                SqlParameter isAdminParam = new SqlParameter("@IsAdmin", SqlDbType.Int);
                isAdminParam.Value = this.IsAdmin;

                SqlParameter idParam = new SqlParameter("@Id", SqlDbType.Int);
                idParam.Value = this.ID;

                command.Parameters.Add(userNameParam);
                command.Parameters.Add(userPassParam);
                command.Parameters.Add(isAdminParam);
                command.Parameters.Add(idParam);

                int rows = command.ExecuteNonQuery();

            }
        }

        public void InsertUser()
        {
            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = ConfigurationManager.ConnectionStrings["ConnString"].ToString();
                conn.Open();

                SqlCommand command = new SqlCommand("INSERT INTO Users(UserName, UserPass, IsAdmin) VALUES(@UserName, @UserPass, 0); SELECT IDENT_CURRENT('Users');", conn);

                SqlParameter userNameParam = new SqlParameter("@UserName", SqlDbType.VarChar, 30);
                userNameParam.Value = this.UserName;

                SqlParameter userPassParam = new SqlParameter("@UserPass", SqlDbType.VarChar, 50);
                userPassParam.Value = this.UserPass;

                command.Parameters.Add(userNameParam);
                command.Parameters.Add(userPassParam);

                var id = command.ExecuteScalar();

                if (id != null)
                {
                    this.ID = Convert.ToInt32(id);
                }
                
            }
        }

        public void Save()
        {
            if (ID == 0)
            {
                InsertUser();
            }
            else
            {
                UpdateUser();
            }
        }

        private void SetErrors(string propertyName, string propertyError)
        {
            errors.Remove(propertyName);
            errors.Add(propertyName, propertyError);
            if (ErrorsChanged != null)
            {
                ErrorsChanged(this, new DataErrorsChangedEventArgs(propertyName));
            }
        }

        private void ClearErrors(string propertyName)
        {
            errors.Remove(propertyName);
            if (ErrorsChanged != null)
            {
                ErrorsChanged(this, new DataErrorsChangedEventArgs(propertyName));
            }
        }

        public IEnumerable GetErrors(string propertyName)
        {
            if (string.IsNullOrEmpty(propertyName))
            {
                return (errors.Values);
            }
            else
            {
                if(errors.ContainsKey(propertyName))
                {
                    return (errors[propertyName]);
                }
                else
                {
                    return null;
                }
            }
        }

        public User Clone()
        {
            User clonedUser = new User();
            clonedUser.UserName = this.UserName;
            clonedUser.UserPass = this.UserPass;
            clonedUser.ID = this.ID;
            clonedUser.IsAdmin = this.IsAdmin;

            return clonedUser;
        }

        public override bool Equals(object obj)
        {

            if (obj == null || GetType() != obj.GetType())
            {
                return false;
            }

            User objUser = (User)obj;

            if (objUser.ID == this.ID) return true;

            return false;
        }

        public override int GetHashCode()
        {
            return ID.GetHashCode();
        }
    }
}
