﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;
using Zadatak1.Model;

namespace Zadatak1.ViewModel
{
    public class LoginWindowViewModel : INotifyPropertyChanged
    {
        private string userSearch;
        private string userPassword;

        public event PropertyChangedEventHandler PropertyChanged;

        public void OnPropertyChange(PropertyChangedEventArgs e)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, e);
            }
        }

        public string UserSearch
        {
            get { return userSearch; }
            set
            {
                if (userSearch == value)
                {
                    return;
                }
                userSearch = value;
                OnPropertyChange(new PropertyChangedEventArgs("UserSearch"));
            }
        }

        public string UserPassword
        {
            get { return userPassword; }
            set
            {
                if (userPassword == value)
                {
                    return;
                }
                userPassword = value;
                OnPropertyChange(new PropertyChangedEventArgs("UserPassword"));
            }
        }

        public LoginWindowViewModel()
        {
            
        }
    }
}
